# V27数据与证据追溯入口

本轮不改变v0.12的14,505条序列及1,036个阳性、13,469个阴性标签，只更新同源组和划分元数据。samples.tsv、proteins.faa、repaired_parent_groups.tsv和split_80_20.tsv是本轮正式入口。

protein_traceability.tsv保留历史所有列，并新增V27_part和V27_moved_development_to_test；homology_group已更新。旧V26相关列仅供历史追溯，不能作为V27划分。

完整measurements、training_qualification、evidence_quality、阴性终点/样本决策仍在冻结数据库及前版已审计数据包中。见 ../../RootColonization_DB_v0.12_effect_band_filter/ 和 ../../V26_publication_evidence_20261016/data_release/。这些来源的旧同源组列不替代当前修补组。

0标签要求原来源QC和阴性资格合格，且每个原合格实测终点具有有限log2效应并位于log2(0.8)至log2(1.2)。这是来源定义下的点效应范围，不是等效性检验证书，不统一等于绝对CFU比例。未测、缺失及未知蛋白不补阴性。所有符合规则的阴性保留，未按1:3或模型得分再次筛选。

阳性继承原已审核的功能证据；证据等级、论文类型与来源限制分别记录。序列映射已在前版独立复核参考DNA翻译和哈希，本轮再次确认序列及标签逐行不变。H3未纳入训练。
