# 文献检索、候选来源与最终纳入：可追溯说明

整理日期：2026-10-18。本次只整理已有档案，没有联网补检、增加研究、修改标签或重训模型。训练库以v0.12记录和V27修补后的同源组为准。

## 实际检索渠道、日期和关键词

档案记录Europe PMC API检索、PubMed/PMC核对、出版社、作者/机构资料库、补充材料及引用追踪。能给出完整检索式和返回数量的查询是Europe PMC；PubMed/PMC被使用不等于保留了完整独立检索式与初筛日志。v0.8/v0.9的可验证扩展检索和来源审核发生于2026-10-09及10-11；既有范围写明“2026-10-11可获取论文”。2026-10-18是整理日期，不是延长收录日期。

关键词围绕root/rhizosphere/rhizoplane、colonization/colonisation、transposon/TnSeq/INSeq/TraDIS以及mutant/mutation/deletion/mutagenesis组织，并辅以菌株、题名和DOI。以下均为实际保存的历史检索式，不是新拟的检索方案：

```text
(root OR rhizosphere OR rhizoplane) AND (transposon OR TnSeq OR INSeq OR TraDIS)
```

```text
TITLE_ABS:"Genome-wide interrogation"
```

```text
DOI:10.7554/eLife.90726
```

```text
(TITLE_ABS:"root colonization" OR TITLE_ABS:"root colonisation" OR TITLE_ABS:"rhizosphere colonization" OR TITLE_ABS:"rhizosphere colonisation") AND (TITLE_ABS:mutant OR TITLE_ABS:mutation OR TITLE_ABS:deletion OR TITLE_ABS:mutagenesis)
```

```text
(TITLE_ABS:root OR TITLE_ABS:rhizosphere OR TITLE_ABS:rhizoplane) AND (TITLE_ABS:transposon OR TITLE_ABS:TnSeq OR TITLE_ABS:INSeq OR TITLE_ABS:TraDIS)
```

完整逐次检索式、UTC时间、URL、服务器命中数、实际保存数和本包路径见literature_selection/search_queries.tsv；原始返回与收据在该目录的archive/中。

## 可核实的数量

23次成功查询共保存1,932条结果出现记录；另有3次请求失败，不算作完成检索。以DOI、PMID、PMCID、来源+ID精确关联去重，得到1,763条唯一书目记录，重复出现169条。不同数据库标识可经同一记录桥接，使用传递并集合并；无任何标识时才用规范化完整题名，不做模糊题名匹配。

**这是已保存档案的重新去重计数，不是已完成标题摘要筛选的数量。**某宽检索服务器显示11,890条，但只保存前1,000条；未获取的后续结果不计已筛。PubMed独立初检、引用追踪新增、完整历史标题摘要/全文筛选及相应排除数未完整保存，不能由最终21项反推。

25个来源目录条目与40条历次审核记录按规范DOI/研究键合并，共50个已有候选来源。65条输入记录折合50个来源，而不是65篇独立全文；40条审核也不代表40篇均完成相同程度审阅。当前最终状态优先于历史pending：例如Dietel2013/Fan2013、SQR9_adhesins2021/Huang2022按同DOI归并后以V27纳入状态为准。

50个来源中，21项有最终蛋白成员；29项没有。29项各分配一个互斥主要原因，原始描述、别名、历史状态和依据逐项保存在candidate_disposition_50_sources.tsv：

- 来源记录经最终蛋白资格筛选后无保留成员：**3**项。
- 来源实验质量不足以单独支持正式标签：**1**项。
- 条件或时点相反，未形成合格一致标签：**6**项。
- 缺少本任务合格的基因扰动定殖终点：**6**项。
- 原菌株位点或完整蛋白对应未解决：**5**项。
- 同一实验的再分析，不计独立来源：**1**项。
- 原始结果、全文或统计依据不可获取或未核实：**5**项。
- 扰动方式不支持本轮原生单蛋白缺失标签：**1**项。
- 作者判定与可复算阈值结果未协调：**1**项。

这里包含**未完成核实而暂不纳入**及**经蛋白记录筛选后无成员**，不能把29项统称为“不合格全文”。特别是3项来源并非当初文献不符合，而是在当前范围和冲突规则后没有保留序列。Wheatley2020保留档案和冲突审计用途，不贡献最终训练蛋白。

**50项也不是由1,763条书目完整初筛后得到的全文数。**本包按DOI给出可回连部分，未回连不等于确定通过引文追踪取得。流程图用分开的面板和虚线表示档案间不完整的联系。历史registry的767条登记也不能当767篇已全文审阅研究。

## 纳入和不纳入原则

需要可识别蛋白编码位点、基因扰动后的根/根际/根内定殖表型以及可核验的实际菌株完整蛋白。纯表达关联、功能注释、植物生长、无植物体外生物膜、初始附着或仅结瘤阶段不直接替代目标表型。实验阶段不同和条件依赖需要按既有规则处理，不能用当前评分决定纳入。

没有实测阴性不是整项研究的排除理由：最终7项双类来源、14项仅阳性。预印本、博士论文、名单证据与实测完整筛选分别保留类型及局限。现有标签不保证均已排除一般生长影响，详见逐研究positive/growth规则。

## 如何用于正文与流程图

可直接使用docs/MANUSCRIPT_METHODS.md的英文方法和图注。figures/literature_and_database_flow.pdf、.svg为矢量图，.png为预览。若期刊要求标准PRISMA式全量初筛，应明确当前历史记录不足，不能把此图伪装成完整系统综述流程。无需新增研究即可如实呈现本研究的档案收集、资格审核及数据整理。
