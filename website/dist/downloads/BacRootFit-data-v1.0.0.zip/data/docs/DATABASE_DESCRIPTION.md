# 数据库描述统计

训练库仍为14,505唯一完整蛋白，1,036阳性、13,469阴性；21研究、21菌株标识。参考文件的organism-name保留原样：同一菌株可能有历史异名，例如Rlv3841两种Rhizobium命名；**参考名称字符串数不是去重后的当前菌种数**。本轮不新造TaxID，不将这种异名差异计作生物学多样性增加。

| strain | reference_organism_names | positive | negative | total |
|---|---|---|---|---|
| CIB | Azoarcus sp. CIB | 3 | 0 | 3 |
| DQS4T | Azoarcus olearius | 77 | 0 | 77 |
| F113 | Pseudomonas ogarae | 4 | 0 | 4 |
| FZB42 | Bacillus velezensis FZB42 | 5 | 0 | 5 |
| KT2440R | Pseudomonas putida KT2440 | 7 | 0 | 7 |
| M130 | — | 121 | 0 | 121 |
| NCIB3610 | Bacillus subtilis | 196 | 2791 | 2987 |
| OAE497 | Rhizobium sp. OAE497 | 46 | 1544 | 1590 |
| OAS795 | Variovorax sp. OAS795 | 6 | 520 | 526 |
| OAS925 | Paraburkholderia sp. OAS925 | 1 | 221 | 222 |
| ORS571 | Azorhizobium caulinodans ORS 571 | 2 | 0 | 2 |
| Pf5 | Pseudomonas protegens Pf-5 | 80 | 1596 | 1676 |
| PsJN | Paraburkholderia phytofirmans PsJN | 29 | 1443 | 1472 |
| R7A | — | 66 | 0 | 66 |
| Rlv3841 | Rhizobium johnstonii 3841;Rhizobium leguminosarum bv. viciae 3841 | 107 | 8 | 115 |
| SF2 | Sinorhizobium fredii CCBAU 25509 | 41 | 1226 | 1267 |
| SQR9 | Bacillus velezensis SQR9 | 5 | 0 | 5 |
| SmR1 | Herbaspirillum seropedicae SmR1 | 116 | 0 | 116 |
| WCS365 | Pseudomonas brassicacearum | 2 | 0 | 2 |
| WCS417 | Pseudomonas simiae | 114 | 3468 | 3582 |
| YX36 | Mucilaginibacter yixingensis | 8 | 652 | 660 |

## 宿主、部位与assay

原正式measurement表只有202条合格观察显式填写plant字段，不能只依据这一列统计宿主。另行恢复26,909条合格观察的context：其中23,677条通过既有condition_id精确连接历史条件表，其余来自已有观察字段或人工审核的单宿主研究范围。新context表不修改正式样本、标签或原表。

来源pooled宿主/品种作为同一组合范围保留，不拆出虚构独立宿主标签；研究范围补充也不等同于每个目标独立测过该范围的每种宿主。宿主/assay可能重叠，同一蛋白出现多次时计为membership，不能把行数之和当14,505。条件元数据中的旧映射未决等历史caveat，不覆盖本轮独立序列映射已通过的结论。

| value | qualified_observations | unique_protein_memberships | positive | negative |
|---|---|---|---|---|
| Arabidopsis thaliana | 6825 | 6795 | 315 | 6480 |
| Brachypodium distachyon | 9828 | 4470 | 90 | 4380 |
| Cucumis sativus | 5 | 5 | 5 | 0 |
| Glycine max | 1282 | 1267 | 41 | 1226 |
| Glycine soja | 1282 | 1267 | 41 | 1226 |
| Gossypium hirsutum | 1676 | 1676 | 80 | 1596 |
| Hordeum vulgare | 230 | 115 | 107 | 8 |
| Lactuca sativa | 3 | 3 | 3 | 0 |
| Lathyrus latifolius | 230 | 115 | 107 | 8 |
| Lens culinaris | 230 | 115 | 107 | 8 |
| Lotus japonicus Gifu and Nfr5; Arabidopsis thaliana Col-0 | 66 | 66 | 66 | 0 |
| Medicago sativa | 234 | 119 | 111 | 8 |
| Medicago truncatula | 222 | 222 | 1 | 221 |
| Oryza sativa | 1285 | 1270 | 44 | 1226 |
| Oryza sativa Nipponbare and IR64 | 121 | 121 | 121 | 0 |
| Pisum sativum | 230 | 115 | 107 | 8 |
| Sesbania rostrata | 2 | 2 | 2 | 0 |
| Setaria viridis | 193 | 193 | 193 | 0 |
| Triticum durum | 1676 | 1676 | 80 | 1596 |
| Zea mays | 1289 | 1274 | 48 | 1226 |

| value | qualified_observations | unique_protein_memberships | positive | negative |
|---|---|---|---|---|
| endosphere CFU | 3 | 3 | 3 | 0 |
| hydroponic rhizosphere at 5dpi | 2 | 2 | 2 | 0 |
| rhizoplane | 8480 | 2943 | 121 | 2822 |
| rhizoplane_plus_endosphere | 3582 | 3582 | 114 | 3468 |
| rhizosphere | 10913 | 4651 | 263 | 4388 |
| rhizosphere competition | 4 | 4 | 4 | 0 |
| rhizosphere competition at 12dpi | 5 | 5 | 5 | 0 |
| rhizosphere competition at 6dpi | 2 | 2 | 2 | 0 |
| root | 575 | 115 | 107 | 8 |
| root CFU | 5 | 5 | 5 | 0 |
| root CFU at 24h | 3 | 3 | 3 | 0 |
| root CFU at 48h without phage | 1 | 1 | 1 | 0 |
| root colonization author categorical panel | 2 | 2 | 2 | 0 |
| root surface competition at 7dpi | 2 | 2 | 2 | 0 |
| root versus liquid | 3016 | 2987 | 196 | 2791 |
| root-associated | 121 | 121 | 121 | 0 |
| root_association | 193 | 193 | 193 | 0 |

| value | qualified_observations | unique_protein_memberships | positive | negative |
|---|---|---|---|---|
| CRISPRi_root_specific_fitness_interaction | 2996 | 2986 | 195 | 2791 |
| legacy_root_screen | 23677 | 11303 | 625 | 10678 |
| primary_author_root_screen_call | 187 | 187 | 187 | 0 |
| single_gene_Tn_mutant_root_assay | 3 | 3 | 3 | 0 |
| single_gene_deletion_root_CFU | 23 | 13 | 13 | 0 |
| single_gene_deletion_root_assay | 2 | 2 | 2 | 0 |
| single_gene_insertion_root_competition | 4 | 4 | 4 | 0 |
| single_gene_mutant_root_assay | 2 | 2 | 2 | 0 |
| single_locus_root_phenotype | 15 | 15 | 15 | 0 |

具体到每研究的宿主、部位、assay见[研究方法元数据](output/study_positive_and_growth_rules.tsv)，观察级补充见[measurement_context_annotations.tsv](output/measurement_context_annotations.tsv)。不同来源root、rhizoplane、rhizosphere、endosphere的测量边界保留，不能静默合并为同一实验证据。

## 证据、序列长度及同源组

| label | evidence_tier | protein_memberships |
|---|---|---|
| 0 | pooled_insertion_screen_limited | 8 |
| 0 | replicated_screen_operational | 13461 |
| 1 | author_affected_list_limited | 193 |
| 1 | author_direct_panel | 38 |
| 1 | doctoral_thesis_replicated_screen_author_hit_list | 66 |
| 1 | pooled_insertion_screen_limited | 107 |
| 1 | replicated_screen_author_shortlist | 121 |
| 1 | replicated_screen_operational | 520 |

| label | n | min | q25 | median | q75 | q95 | q99 | max | mean | SD |
|---|---|---|---|---|---|---|---|---|---|---|
| all | 14505 | 29.0000 | 206.0000 | 309.0000 | 441.0000 | 788.0000 | 1256.8400 | 4901.0000 | 360.5442 | 272.1746 |
| 1 | 1036 | 50.0000 | 219.0000 | 318.0000 | 455.2500 | 817.0000 | 1386.7500 | 2364.0000 | 375.8678 | 251.7325 |
| 0 | 13469 | 29.0000 | 204.0000 | 309.0000 | 440.0000 | 786.6000 | 1247.0000 | 4901.0000 | 359.3655 | 273.6569 |

正式库7,799个修补后连通组，组大小中位数1，最大220；5,757个singleton。335个组同时有不同蛋白的正负标签，这与相同精确序列标签冲突不是一回事；它提示不能将整个家族当相同功能真值。正式库已知精确序列相反标签交集仍为0。

| size_band | groups | proteins | positive | negative |
|---|---|---|---|---|
| 1 | 5757 | 5757 | 368 | 5389 |
| 2-5 | 1794 | 4667 | 468 | 4199 |
| 6-20 | 200 | 1784 | 136 | 1648 |
| 21-100 | 44 | 1633 | 53 | 1580 |
| >100 | 4 | 664 | 11 | 653 |

![序列长度与修补后同源组](figures/database_lengths_groups.png)

组统计只数正式库14,505成员；父库桥接序列仍影响组连接，但不作为额外训练样本。所有统计由当前固定表直接计算。[描述摘要](output/database_description.json)。
