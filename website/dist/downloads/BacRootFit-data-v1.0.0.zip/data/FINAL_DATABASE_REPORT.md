# 最终数据库与文献筛选交付说明

本交付整理于2026-10-18。**这是已有v0.12数据库与V27修复组的正式整理版，不是新增研究后的新数据库，也未改变训练样本或标签。**

| 项目 | 数量 |
|---|---:|
| 唯一完整蛋白 | 14,505 |
| 阳性 / 阴性 | 1,036 / 13,469 |
| 正式研究 / 菌株标识 | 21 / 21 |
| 双类研究 / 仅阳性研究 | 7 / 14 |
| V27修补后同源组 | 7,799 |
| 合格观察 / 全部关联观察 | 26,909 / 28,482 |
| 开发 / 内部测试 | 11,664 / 2,841 |
| 外部H3，另存 | 86正 / 1,792负 |

## 1. 文献收集和筛选已经补到什么程度

全部实际保存检索式、日期、URL、命中与保存数、原始JSON及收据已整理。23次成功查询保存1,932条出现记录，精确标识去重后1,763条，重复169条。3次失败请求单列；宽检索的11,890服务器命中不冒充完整获取或筛选。

来源目录25条与历史审核40条按DOI/来源键合并得到50个已有候选来源。最终21项贡献正式蛋白，29项不贡献；每项保留一个主要原因和原始审核依据。完整历史标题摘要、全文筛选和各阶段排除数没有保存齐全，未用1,763、50、29拼成虚假PRISMA。**不贡献的29项包含未核实完的线索、再分析、证据/映射限制以及3项经蛋白筛选后无成员的历史来源，不能统称29篇全文排除。**

图：figures/literature_and_database_flow.pdf/.svg/.png。英文正文及图注：docs/MANUSCRIPT_METHODS.md。中文详细说明：docs/LITERATURE_SELECTION.md。所有数量由脚本从本地冻结档案复算，未新增联网检索。

## 2. 最终标签与一般生长控制

阳性沿用逐来源审核的效应方向、统计/作者判定和条件合并规则。并非所有研究使用同一P或效应阈值；缺失阈值不补写。富集型结果按来源处理，不能自动当阳性或最终阴性。输出文件output/study_positive_and_growth_rules.tsv逐研究列出阳性、合并、增强方向、生长对照、实际应用和限制。docs/POSITIVE_AND_GROWTH_RULES.md提供叙述。

标签针对记录条件下基因扰动关联的定殖表型，不是普遍功能有无，也不保证全部阳性已排除一般生长缺陷。因此方法中使用colonization-associated perturbation phenotype；对于生长控制较充分的来源可另作分层描述。

阴性先须通过父库的实测、作者非命中和来源QC等要求，再施加v0.12统一范围：至少一个合格终点，且所有原合格终点均为允许类型的有限log2效应，位于[log2(0.8),log2(1.2)]闭区间。不平均条件/assay/guide；不将缺失或名单外视为零。35,449条父库合格阴性中，21,913条范围外、67条缺失必要有限效应，保留13,469；1,036条阳性全部保留。

此范围是2**来源定义的标准化log2对比，不总等于突变株/野生型绝对CFU。它是点效应过滤，不是置信区间等效性检验；不强制1:3，没有随机欠采样，也未按模型分数选负例。完整35,449条样本判定与102,483个父库阴性合格终点审核在audit/，用于复核过滤，不作为最终样本导入。

## 3. 逐研究最终样本

| 研究键 | 阳性成员 | 阴性成员 | 合计成员 |
|---|---:|---:|---:|
| BlancoRomero2024 | 4 | 0 | 4 |
| Budiharjo2014 | 3 | 0 | 3 |
| CIB2021 | 3 | 0 | 3 |
| Cole2017 | 114 | 3468 | 3582 |
| DoAmaral2020 | 193 | 0 | 193 |
| Fan2013 | 2 | 0 | 2 |
| Ghaly2025 | 80 | 1596 | 1676 |
| Huang2022_SQR9 | 3 | 0 | 3 |
| Ji2023 | 41 | 1226 | 1267 |
| Knights2024 | 107 | 8 | 115 |
| Liu2020_CheY | 2 | 0 | 2 |
| LopezFarFan2019 | 2 | 0 | 2 |
| Matilla2007 | 5 | 0 | 5 |
| Minhas2026 | 196 | 2791 | 2987 |
| Perry2021_R7A | 66 | 0 | 66 |
| Torres2025 | 82 | 3728 | 3810 |
| Torres2026_YX36 | 8 | 652 | 660 |
| Tzipilevich2021 | 1 | 0 | 1 |
| Wallner2022_M130 | 121 | 0 | 121 |
| Wiesmann2023 | 2 | 0 | 2 |
| Xu2019_SQR9 | 2 | 0 | 2 |

**研究成员合计14,506＝1,037阳性归属＋13,469阴性归属；唯一序列仍为14,505＝1,036＋13,469。**RC03_1700由Minhas2026和Tzipilevich2021共同支持，只训练一次。同一菌株也可能对应多篇研究，菌株数不由研究数相加。原catalog保留25行，其中4个archive-only来源不算正式研究；studies_included.tsv严格21行。

## 4. 序列、证据与同源组

data_release/samples.tsv是唯一蛋白的权威标签表；proteins.faa与之逐条ID、长度、20标准氨基酸和SHA256核对。protein_traceability.tsv与sequence_mapping_replay.tsv保留位点、参考序列、坐标和独立翻译依据。已知精确序列相反标签按既定冲突策略处理；不同蛋白的同源组内混合标签不当作精确序列冲突。

homology_group使用V27修补组7,799个，不使用v0.12原来的7,816。图阈值identity>=30%、两侧coverage>=80%、E<=0.001，保留父库桥接路径，不将桥接序列加入训练。V27修补未修改样本、序列、标签。output/graph/policy.json保存定义及搜索范围。工具是启发式检索，检查通过表示当前工具/参数下未检出跨侧合格命中，不是所有可能同源关系的穷尽证明。

当前V27划分见output/split_80_20.tsv：开发11,664（829正/10,835负）、内部测试2,841（207正/2,634负），组不跨侧。traceability中的original_split是历史字段，V27_part才是当前字段；不使用旧split覆盖新split。该划分与新数据库SQLite完全一致。

## 5. 观察表、数据库和使用方式

- **建模**：读data_release/samples.tsv和proteins.faa；不要把measurement行直接当独立蛋白样本。
- **合格标签依据**：data_release/measurements_qualified.tsv，26,909行，与evidence_quality.qualifying_evidence=1和context表逐ID一致。
- **完整审计**：measurements_all_linked.tsv，28,482行，包含最终蛋白关联的未合格观察及历史对照；这不代表28,482条独立样本或全都支持标签。来源键可能包括archive-only研究。
- **数据库**：root_colonization_v012_V27.sqlite由本包权威表重新构建，不复制含旧组的历史SQLite。samples与protein_sequences为14,505行；studies为21行，study_catalog_all为25行；H3不在主库样本表。视图samples_with_split和qualified_observations_with_context便于查询。
- **外部H3**：external_H3/独立保存1,878条的FASTA、标签、原始逐基因/插入表和标签说明。不是新增第22项训练研究。历史暴露和浮萍全表面3小时表型限制保持。

示例SQL：

```sql
SELECT label, COUNT(*) FROM samples GROUP BY label;
SELECT study, positive, negative FROM studies ORDER BY study;
SELECT COUNT(DISTINCT homology_group) FROM samples;
SELECT V27_part, label, COUNT(*) FROM samples_with_split GROUP BY V27_part, label;
```

## 6. 交付边界与复核

本次没有新研究、重新标注、重新训练或外部发送。数据库描述用菌株标识与保留的参考organism名称，未把历史异名字符串当作新增菌种。标签/FASTA/同源组/划分/观察ID/SQLite计数已由构建脚本核查。artifact_sources.tsv追溯所有直接复制文件；manifest_sha256.tsv校验本包；verification.json记录结果。source/build_v27_final_database_20261018.py为本次构建脚本，源资料仍需原工作区或本包归档才能复算全部来源。
